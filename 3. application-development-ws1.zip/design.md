**Output Model:**

- Required:Ticket number - starts with AAP and ends with up to 5 digit numbers, team name - string, area - string but up to 100 words, feedback - string but up to 500 words, \
  Optional: problem - string but up to 500 words, suggestion - string but up to 500 words
- In each area, it will have multiple feedback, problem and suggestion.

**Input Model:**

- The survey text, maybe the team name, the ticket number.
- Text can't be empty, ticket number can’t be empty, the team name can’t be empty.

**Examples:**

- AAP00125\
  Team: Compliance.\
  Text: Overall I still really enjoy working here and the people on my immediate team are great, genuinely some of the best colleagues I've had. That said there are a few things worth flagging. The biggest one is workload — we've lost two people this year and they haven't been backfilled, so the rest of us are absorbing the extra work and it's starting to show. I've been doing 50+ hour weeks for about three months now and a couple of things have slipped through that normally wouldn't. I think we either need to backfill those roles or have an honest conversation about reprioritising what's actually in scope.

  Communication from leadership is hit and miss. When the restructure was announced we found out about it through the all-staff email at the same time as everyone else, with no heads up from our own manager, which felt a bit off. To be fair our direct manager is good once you get time with them, it's more the layer above that feels distant. It would help to have a short monthly update that actually explains the "why" behind decisions rather than just the what.\
  \
  On tools — the new CRM is slow and crashes a few times a week, and the search basically doesn't work so I end up exporting to a spreadsheet anyway. Not a dealbreaker but it adds up over a week. Training was also a bit rushed; we got a 45 minute demo and then were expected to be live the next day.

  Last thing, career development. I've been in the same band for nearly four years and I don't really have a clear picture of what progression looks like. I'd love a proper development conversation that isn't just bolted onto the annual review. Happy to chat more if useful.
- AAP00342\
  Team: Advanced Analytics and Planning\
  Text: Honestly not sure how much point there is filling this in because last year's survey didn't lead to anything visible, but here goes.

  Recognition is the big one for me. The team pulled off the migration on time and under budget and there wasn't so much as a thank you from above — meanwhile when something goes wrong we hear about it within the hour. It's demoralising. People notice that imbalance more than management thinks.

  The hybrid policy change has gone down badly. We were told it was three days flexible, then suddenly it's a mandated three fixed days with no consultation, and for people with caring responsibilities or a long commute that's a real problem. A few good people have already started looking elsewhere because of it. I don't have a perfect answer but at minimum we should have been asked before it was decided.

  Workload is unsustainable in our area specifically. We're the team everything funnels through but we have no ability to say no, so everyone else's deadlines become our crisis. There's no clear prioritisation framework so it's just whoever shouts loudest.

  And the kitchen on level 4 has been broken for two months, which is a small thing but it's the kind of small thing that makes you feel like nobody's looking after the basics.